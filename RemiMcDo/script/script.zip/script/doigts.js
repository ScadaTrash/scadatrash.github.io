var words = [
"doigt/doigt.gif",
"doigt/doigt2.gif",
"doigt/doigt3.gif",
"doigt/doigt4.gif",
"doigt/doigt5.gif",
"doigt/doigt6.gif",
"doigt/doigt7.gif",
"doigt/doigt9.gif",
"doigt/doigt11.gif",
"doigt/doigt12.gif",
"doigt/doigt13.gif",
"doigt/doigt14.gif",
"doigt/doigt15.gif",
"doigt/doigt16.gif",
"doigt/doigt17.gif",
"doigt/doigt18.gif",
"doigt/doigt19.gif",
"doigt/doigt20.gif",
"doigt/doigt21.gif",
"doigt/doigt22.gif",
"doigt/doigt23.gif",
"doigt/doigt24.gif",
]

var doigt = words[Math.floor(Math.random() * words.length)];
document.write('<img src="'+doigt+'" style="width:70%" title="Il paraît qu\'on peut actualiser pour voir encore plus de doigts..."/>');